export const fontForLang = (lang) => {
  switch (lang) {
    case 'ja': return 'NotoJP';
    case 'zh': return 'NotoSC';
    default:   return 'DungGeunMo';
  }
};

export const lineH = (size) => Math.round(size * 1.25);
